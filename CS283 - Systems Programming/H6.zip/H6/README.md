To run the program, type in command line: 
`make all` 

There will be four output files:
12-16
12-17
dotpr-hw
hello-hw

To run any of them, type: 
`./12-16` 
`./12-17 <arg>` 
`./dotpr-hw`
`./hello-hw`

For problem `12-16`, please enter an integer to specify the number of threads to run  ./12.16 <number of threads> 
`./12-17 3` 





